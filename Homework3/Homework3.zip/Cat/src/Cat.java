
public class Cat
{
    private Double originWeight;
    private Double weight;

    private Double minWeight;
    private Double maxWeight;
    private static Integer count = 0;

    public Cat()
    {
        Cat.count++;
        weight = 1500.0 + 3000.0 * Math.random();
        originWeight = weight;
        minWeight = 1000.0;
        maxWeight = 9000.0;
    }

    public Cat(Double weight) {
        Cat.count++;
        this.weight = weight;
        originWeight = weight;
        minWeight = 100.0;
        maxWeight = 500.0;
    }
    public static Integer getCount() {
        return Cat.count;
    }

    public Cat deepCopy() {
        Cat obj = new Cat();
        obj.weight = this.weight;
        obj.originWeight = this.originWeight;
        obj.minWeight = this.minWeight;
        obj.maxWeight = this.maxWeight;
        return obj;
    }
    public void meow()
    {
        weight = weight - 1;
        updateCatsCount();
        System.out.println("Meow");
    }

    public void feed(Double amount) {
        weight = weight + amount;
        updateCatsCount();
    }

    public void drink(Double amount) {
        weight = weight + amount;
        updateCatsCount();
        if(getStatus() == "Dead" || getStatus() == "Exploded") count--;
    }

    public Double getConsumedFood(){
        if(weight < originWeight) {
            System.out.println("It seems that Cat didnt have any meal for some time");
            return 0.0;
        } else {
            return (weight - originWeight);
        }
    }

    public void visitToilet() {
        this.weight -= 5;
        if(this.weight <= minWeight) {
            System.out.println("It was last visit to toilet for this cat ever");
        } else {
            System.out.println("Weight of cat after toilet: " + this.weight);
        }
    }

    public Double getWeight()
    {
        return weight;
    }

    public String getStatus()
    {
        if(weight < minWeight) {
            return "Dead";
        }
        else if(weight > maxWeight) {
            return "Exploded";
        }
        else if(weight > originWeight) {
            return "Sleeping";
        }
        else {
            return "Playing";
        }
    }

    public void updateCatsCount(){
        if(getStatus() == "Dead" || getStatus() == "Exploded"){
            Cat.count--;
        }
    }
}